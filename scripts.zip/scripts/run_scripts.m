%-------------------------------------------------------------------------
% fMRI processing stream for SPM12
% Written by: Doby Rahnev
% Last updated: 4/16/2019
% ------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%
% INSTRUCTIONS FOR USE
%%%%%%%%%%%%%%%%%%%%%%%%%
%
% 1. To run these codes
%   Always call this file (run_script.m). Update the files in the folder
%   userScripts (especially study_info.m) in the beginning of the project.
%   Then just change the components to run here.
%
% 2. Expected structure of files (follow structure in INFO.dir)
% - parent folder (for the whole study)
%    - MRI_data
%       - subject_names
%           - DICOM
%               - folder for T1
%               - folders for all EPI
%           - NIFTI (created by the script)
%               - same subfolders as DICOM (created by the script)
%    - Analyses
%        - behavioralData
%    - scripts (for that project)
%
% 3. Order of processing steps
%   Can be specified completely in study_info.m.
%
%-------------------------------------------------------------------------

%% Prepare the space
clear
clc
close all


%% Get study information
addpath(genpath(pwd));
INFO = study_info;


%% PREPROCESSING
% Choose from 'dicomImport', 'despike', 'sliceTime', 'realign', 'segment',
% 'coregister', 'norm', 'smooth', and 'extractPhysio'. Several components 
% can be specified simultaneously. For simplicity, you can also specify 
% 'PRE_setOrigin' and 'POST_setOrigin' for all components before and after 
% setting the origin.
%INFO.preprocJobs = {'PRE_setOrigin'};
INFO.preprocJobs = {'POST_setOrigin'};
%INFO.preprocJobs = {'smooth'};
%preprocManager(INFO);

%% DATA CHECKS
% Checks normalization by displaying the registration of the normalizaed T1 
% images across subjects. Requires subject names. No more than 15 subjects
% at a time can be viewed.
%checkRegistrationAcrossSubj(INFO, {'sub1','sub2'});

% Plots motion for each subject selected and each run. 
%plotMotion(INFO);

% Plots time course for each slice for the data from
% the specified preprocessing step (e.g., plotTimecourse(INFO, 'func'));
%plotTimecourses(INFO, 'smooth');

% Check registration of T1 to EPI files. Only functions one subject at a
% time (subjStr should be the subject name as a string). Select the
% preprocessing step to use, as well as whether the anatomical scan should
% be the normalized one ('normAnat') or original one ('origAnat').
%checkRegistrationWithinSubj(INFO, 'sub1', 'smooth', 'normAnat');

% Choose intermediate steps to delete. Select from 'func', 'despike',
% 'sliceTime', 'realign', 'norm', and 'smooth'
%cleanUpPreprocessing(INFO, {'despike','realign','norm'});

% Plot tSNR. Third input is the runs to be analyzed, 4th input is the run
% to be diplayed
plotTSNR(INFO, 'func', 1:5, 1);

%% FIRST LEVEL
%firstLevel(INFO)

% ROI analyses
%roiAnalyses

% PPI analyses
%define_VOI(INFO)
%create_PPI(INFO)

%% SECOND LEVEL
%secondLevel(INFO)