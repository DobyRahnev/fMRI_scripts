function backNorm(structuralImage, ROItoBackNorm, outputDirectory, newT1name, newROIname, display)

% Create a TEMP folder in the output folder for temporary files
tempFolder = fullfile(outputDirectory, 'TEMP');
mkdir(tempFolder);

% Copy T1 and the ROI to temp, so that we don't change the originals
orig_T1 = fullfile(tempFolder,'T1_orig.nii');
copyfile(structuralImage, orig_T1);
[path, name, extension] = fileparts(ROItoBackNorm);
orig_ROI = fullfile(tempFolder, [name extension]);
copyfile(ROItoBackNorm, orig_ROI);

% Steps to cut the T1
system(['3drefit -deoblique -xorigin cen -yorigin cen -zorigin cen ' orig_T1]);
midstep_t1_file = fullfile(tempFolder,'T1_midstep.nii');
system(['3dresample -orient RPI -inset ' orig_T1 ' -prefix ' midstep_t1_file]);
final_T1 = fullfile(outputDirectory, newT1name);
system(['3dZcutup -keep 60 240 -prefix ' final_T1 ' ' midstep_t1_file]);
system(['3drefit -xorigin cen -yorigin cen -zorigin cen ' final_T1]);

% SPM Steps
res = spm_preproc(final_T1);
[po pin] = spm_prep2sn(res);
inv_param_fl = fullfile(tempFolder, 'T1_cut_seg_inv_sn.mat');
norm_param_fl = fullfile(tempFolder, 'T1_cut_seg_sn.mat');
save(inv_param_fl,'-struct','pin');
save(norm_param_fl,'-struct','po');

% Batch SPM step
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');
matlabbatch{1}.spm.spatial.normalise.write.subj.matname = {inv_param_fl};
matlabbatch{1}.spm.spatial.normalise.write.subj.resample = {[orig_ROI ',1']};
matlabbatch{1}.spm.spatial.normalise.write.roptions.preserve = 0;
matlabbatch{1}.spm.spatial.normalise.write.roptions.bb = [-78 -112 -50
    78 76 85];
matlabbatch{1}.spm.spatial.normalise.write.roptions.vox = [2 2 2];
matlabbatch{1}.spm.spatial.normalise.write.roptions.interp = 1;
matlabbatch{1}.spm.spatial.normalise.write.roptions.wrap = [0 0 0];
matlabbatch{1}.spm.spatial.normalise.write.roptions.prefix = 'w';
spm_jobman('run',matlabbatch);

% Because the bounding box is wrong we still have to resample
backNormed_ROI = fullfile(tempFolder, ['w', name, extension]);
final_ROI = fullfile(outputDirectory, newROIname);
system(['3dresample -master ' final_T1 ' -inset ' backNormed_ROI ' -prefix ' final_ROI]);

% Delete temporary files
rmdir(tempFolder,'s')

% Check whether back-normed ROI is in correct position
if display
    spm_check_registration(final_T1, final_ROI);
end