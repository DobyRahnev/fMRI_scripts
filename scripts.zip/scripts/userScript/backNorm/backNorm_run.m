%backNorm_run

clear

subject = 'sub6';
newT1 = 'Dan_T1_cut.nii';
newROI = 'Dan_rFEF_struct.nii';

ROOT = fullfile('//home/despo/rahnev/tmsMRI/Projects/localizePFC/MRI_data', subject);
structuralImage = fullfile(ROOT, 'NIFTI', 'anatomical', ['anat_' subject '.nii']);
ROItoBackNorm = fullfile(ROOT, 'TMS_sites', 'rFEF_31_-2_47.nii');

backNorm(structuralImage, ROItoBackNorm, fullfile(ROOT, 'TMS_sites'), newT1, newROI, 1)
