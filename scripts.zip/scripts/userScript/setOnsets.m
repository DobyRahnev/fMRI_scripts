function events = setOnsets(INFO, modelName, subjStr, runName)

%Remember to account for removed volumes and slice time correction (if the
%reference slice is not the first)

if strcmp(modelName, 'model1') || strcmp(modelName, 'model2')

    % Load the results file
    resultsFile = fullfile(INFO.dir.root.name, INFO.dir.root.analyses.name, INFO.dir.root.analyses.behavData.name, ...
        subjStr, ['timings_' runName '.mat']);
    load(resultsFile);

    % Determine the event names, onsets, and durations
    events.names = {'1-pulse,low','1-pulse,med','1-pulse,high',...
        '2-pulse,low','2-pulse,med','2-pulse,high',...
        '5-pulse,low','5-pulse,med','5-pulse,high',...
        '10-pulse,low','10-pulse,med','10-pulse,high'};
    numPulsesEvent = [1 1 1 2 2 2 5 5 5 10 10 10];
    for event=1:12
        events.durations{event} = (numPulsesEvent(event)-1) * .111;
        events.onsets{event} = [];
    end
    for trial=1:length(trialOnsets_inSec)
        events.onsets{find(numPulsesEvent==numPulses(trial), 1) + intensity(trial) - 1}(end+1) = ...
            trialOnsets_inSec(trial);
    end
elseif strcmp(modelName, 'model3_intensityOnly')

    % Load the results file
    resultsFile = fullfile(INFO.dir.root.name, INFO.dir.root.analyses.name, INFO.dir.root.analyses.behavData.name, ...
        subjStr, ['timings_' runName '.mat']);
    load(resultsFile);

    % Determine the event names, onsets, and durations
    events.names = {'low','med','high'};
    for event=1:3
        events.durations{event} = 0;
        events.onsets{event} = [];
    end
    for trial=1:length(trialOnsets_inSec)
        events.onsets{intensity(trial)}(end+1) = ...
            trialOnsets_inSec(trial);
    end
else
    Error('Model name not found!')
end