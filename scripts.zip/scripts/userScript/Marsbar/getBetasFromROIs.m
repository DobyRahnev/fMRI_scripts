function getBetasFromROIs(INFO)

%-------------------------------------------------------------------------
% Gets beta and contrast values from MarsBaR ROIs.
%
% This file is to be called from run_scripts.m which controls what
% processing steps to run.
%-------------------------------------------------------------------------

folderWithROIs = 'ROIs'; %folder is located in the main folder for each subject
folderWithMarsbarROIs = 'marsbar_ROIs'; %located in folder above

% Standard Marsbar check ups
% Start marsbar to make sure spm_get works
marsbar('on')

% Set up the SPM defaults, just in case
spm('defaults', 'fmri');

% Loop through subjects
for subject=2:12%INFO.subjects
    subject
    
    % Determine names and paths
    subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
    subjPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subjStr);
    SPMfullPath = fullfile(subjPath, INFO.dir.root.MRI.subj.first_level.name, INFO.model, 'SPM.mat');
    
    % Get all ROIs
    marsbarRoiPath = fullfile(subjPath, folderWithROIs, folderWithMarsbarROIs);
    rois = dir(fullfile(marsbarRoiPath, '*_roi.mat'));
    
    % Extract beta values
    for roiNum=1:length(rois)
        roiFullPath = fullfile(marsbarRoiPath, rois(roiNum).name);
        [betaValues(:,roiNum), contrastValues{roiNum}] = extractBetas(roiFullPath, SPMfullPath);
        roiNames{roiNum} = rois(roiNum).name;
    end

    % Save the results
    save(fullfile(marsbarRoiPath,'betaValues.mat'),'betaValues', 'contrastValues', 'roiNames');
    
    % Clear values for next subject
    clear betaValues contrastValues roiNames
end
