%analyzeROIdata

%-------------------------------------------------------------------------
% Analyze beta values from MarsBaR ROIs. Beta values need to be extracted
% first by calling getBetasFromROIs.m.
%
% This file is to be called from run_scripts.m which controls what
% processing steps to run.
%-------------------------------------------------------------------------

folderWithROIs = 'ROIs'; %folder is located in the main folder for each subject
folderWithMarsbarROIs = 'marsbar_ROIs'; %located in folder above
task_baseline_contrastNum = 1;
iHigh_iLow_contrastNum = 2;
noStimHigh_noStimLow_contrastNum = 4;
iHighHit_iLowHit_contrastNum = 8;
high_low_contrastNum = 10;

% Standard Marsbar check ups
% Start marsbar to make sure spm_get works
marsbar('on')

% Set up the SPM defaults, just in case
spm('defaults', 'fmri');

%% Analyze rDLPFC
% display('------------- right DLPFC -------------');
% for subject=INFO.subjects
%     
%     % Determine names and paths
%     subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
%     subjPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subjStr);
%     
%     % Load the results
%     marsbarRoiPath = fullfile(subjPath, folderWithROIs, folderWithMarsbarROIs);
%     load(fullfile(marsbarRoiPath,'betaValues.mat'));
%     
%     % Extract the contrasts from teh relevant ROIs
%     roiFound = 0;
%     for roiNum=1:length(roiNames)
%         if ~isempty(findstr('rDLPFC', roiNames{roiNum}))
%             roiFound = roiFound + 1;
%             task_baseline(subject,roiFound) = contrastValues{roiNum}.con(task_baseline_contrastNum);
%             iHigh_iLow(subject,roiFound) = contrastValues{roiNum}.con(iHigh_iLow_contrastNum);
%             noStimHigh_noStimLow(subject,roiFound) = contrastValues{roiNum}.con(noStimHigh_noStimLow_contrastNum);
%             iHighHit_iLowHit(subject,roiFound) = contrastValues{roiNum}.con(iHighHit_iLowHit_contrastNum);
%             high_low(subject,roiFound) = contrastValues{roiNum}.con(high_low_contrastNum);
%         end
%     end
% end
% task_baseline
% ttest(task_baseline)
% iHigh_iLow
% ttest(iHigh_iLow)
% noStimHigh_noStimLow
% ttest(noStimHigh_noStimLow)
% iHighHit_iLowHit
% ttest(iHighHit_iLowHit)
% high_low
% ttest(high_low)


%% Analyze rIPS
display('------------- right IPS -------------');
for subject=INFO.subjects
    
    % Determine names and paths
    subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
    subjPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subjStr);
    
    % Load the results
    marsbarRoiPath = fullfile(subjPath, folderWithROIs, folderWithMarsbarROIs);
    load(fullfile(marsbarRoiPath,'betaValues.mat'));
    
    % Extract the contrasts from teh relevant ROIs
    roiFound = 0;
    for roiNum=1:length(roiNames)
        if ~isempty(findstr('rIPS', roiNames{roiNum}))
            roiFound = roiFound + 1;
            task_baseline(subject,roiFound) = contrastValues{roiNum}.con(task_baseline_contrastNum);
            iHigh_iLow(subject,roiFound) = contrastValues{roiNum}.con(iHigh_iLow_contrastNum);
            noStimHigh_noStimLow(subject,roiFound) = contrastValues{roiNum}.con(noStimHigh_noStimLow_contrastNum);
            iHighHit_iLowHit(subject,roiFound) = contrastValues{roiNum}.con(iHighHit_iLowHit_contrastNum);
            high_low(subject,roiFound) = contrastValues{roiNum}.con(high_low_contrastNum);
        end
    end
end
task_baseline
ttest(task_baseline)
iHigh_iLow
ttest(iHigh_iLow)
noStimHigh_noStimLow
ttest(noStimHigh_noStimLow)
iHighHit_iLowHit
ttest(iHighHit_iLowHit)
high_low
ttest(high_low)
