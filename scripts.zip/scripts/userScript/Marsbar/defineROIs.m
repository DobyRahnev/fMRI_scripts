function defineROIs(INFO)

%-------------------------------------------------------------------------
% Builds MarsBaR ROIs.
%
% This file is to be called from run_scripts.m which controls what
% processing steps to run.
%-------------------------------------------------------------------------

folderWithROIs = 'ROIs'; %folder is located in the main folder for each subject
folderWithMarsbarROIs = 'marsbar_ROIs'; %located in folder above

% Standard Marsbar check ups
% Start marsbar to make sure spm_get works
marsbar('on')

% Set up the SPM defaults, just in case
spm('defaults', 'fmri');

% Load coordinates
% Column 1: subject number
% Column 2: region (1: right DLPFC, 2: left DLPFC, 3: right IPS, 4: left IPS)
% Column 3: ROI version (1 or 2)
% Columns 4-6: x, y, and z coordinates of ROI
coordinates = xlsread(fullfile(INFO.dir.root.name, INFO.dir.root.analyses.name, 'ROIs_for_import.xlsx'));
regionName = {'rDLPFC', 'lDLPFC', 'rIPS', 'lIPS'};

% Loop through subjects
for subject=INFO.subjects
    
    % Determine names and paths
    subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
    subjPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subjStr);
    roiPath = fullfile(subjPath, folderWithROIs);
    
    % Check if folders for ROIs are created
    if ~exist(roiPath, 'dir')
        mkdir(roiPath);
    end
    if ~exist(fullfile(roiPath,folderWithMarsbarROIs), 'dir')
        mkdir(fullfile(roiPath,folderWithMarsbarROIs));
    end
    
    % Build spherical 
    subCoord = coordinates(coordinates(:,1)==subject,:);
    dirToSave = fullfile(roiPath,folderWithMarsbarROIs);
    radius = 3;
    for roiNum=1:size(subCoord,1)
        roiName = ['S' num2str(subject) '_' regionName{subCoord(roiNum,2)} '_v' num2str(subCoord(roiNum,3)) '_radius' num2str(radius)];
        peak = subCoord(roiNum,4:6);
        buildSphereROI(roiName, peak, radius, dirToSave, 0)
    end
    
    
end
