function contrasts = setContrasts(modelName, numRegressors, numSess)

% Define contrasts
if strcmp(modelName, 'model1') || strcmp(modelName, 'model2')
    % %conditions:
    %1: '1-pulse,low'
    %2: '1-pulse,med'
    %3: '1-pulse,high'
    %4: '2-pulse,low'
    %5: '2-pulse,med'
    %6: '2-pulse,high'
    %7: '5-pulse,low'
    %8: '5-pulse,med'
    %9: '5-pulse,high'
    %10: '10-pulse,low'
    %11: '10-pulse,med'
    %12: '10-pulse,high'
    
    contrasts.name{1} = 'TMS > baseline';
    contrasts.formula{1} = repmat([ones(1,12) zeros(1,numRegressors)], 1, numSess);
    
    contrasts.name{end+1} = 'high TMS > low TMS';
    contrasts.formula{end+1} = repmat([repmat([-1 0 1],1,4) zeros(1,numRegressors)], 1, numSess);
    
    contrasts.name{end+1} = 'low TMS > high TMS';
    contrasts.formula{end+1} = repmat([repmat([1 0 -1],1,4) zeros(1,numRegressors)], 1, numSess);
    
    contrasts.name{end+1} = '10-pulse high TMS > 1-pulse low TMS';
    contrasts.formula{end+1} = repmat([-1 zeros(1,10) 1 zeros(1,numRegressors)], 1, numSess);
    
    contrasts.name{end+1} = '10-pulse high TMS > 10-pulse low TMS';
    contrasts.formula{end+1} = repmat([zeros(1,9) -1 0 1 zeros(1,numRegressors)], 1, numSess);
    
    
elseif strcmp(modelName, 'model3_intensityOnly')
    % %conditions:
    %1: low intensity, all bursts
    %2: med intensity, all bursts
    %3: high intensity, all bursts
    
    contrasts.name{1} = 'TMS > baseline';
    contrasts.formula{1} = repmat([ones(1,3) zeros(1,numRegressors)], 1, numSess);
    
    contrasts.name{end+1} = 'high TMS > low TMS';
    contrasts.formula{end+1} = repmat([-1 0 1 zeros(1,numRegressors)], 1, numSess);
    
    contrasts.name{end+1} = 'low TMS > high TMS';
    contrasts.formula{end+1} = repmat([1 0 -1 zeros(1,numRegressors)], 1, numSess);
    
    contrasts.name{end+1} = 'high TMS > baseline';
    contrasts.formula{end+1} = repmat([0 0 1 zeros(1,numRegressors)], 1, numSess);
end