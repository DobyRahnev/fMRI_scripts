function INFO = study_info

%-------------------------------------------------------------------------
% Contains all information about the study.
% 
% This file is to be called from run_scripts.m which controls what
% processing steps to run.
%-------------------------------------------------------------------------

%% SUBJECTS
% Specify a vector with subjects for the current analysis (e.g. 1:20)
INFO.subjects = 1:4;

% Subjects for which the origin was set manually (initially: [])
INFO.originSetFor = [1,2,3,4];


%% FIRST LEVEL
% Edit setOnsets.m and setContrasts.m in the folder userScripts for the
% first level GLM to perform properly.

% GLM model name
INFO.model = 'model4';

% Names of the runs that go inside the model. Normal usage:
% INFO.modelRuns = {'run1','run2','run3'};
% If different runs are used for each subject, define for each subject:
% INFO.modelRuns{subj} = {'run1','run2'};
INFO.modelRuns{1} = {'run1','run2','run5'};       %for S1
INFO.modelRuns{2} = {'run1','run5'};              %for S2
INFO.modelRuns{2} = {'run1','run5'};              %for S3
INFO.modelRuns{4} = {'run1','run2','run3','run4'}; %for S4

% Units to specify scans in, either 'scans' or 'secs'
INFO.units = 'secs';

% Motion regressors to include
INFO.motion.raw = 1; %these are the 6 realignment parameters
INFO.motion.squared = 0;
INFO.motion.firstDerivative = 0;
INFO.motion.secondDerivative = 0;

% Global signals to regress out. Usually not a good idea to regress the
% global grey matter. Input the threshold that you want to use for the
% probability that the voxel contains this type of data (e.g., put 0 if you
% don't want a regressor and .99 or .9999 if you do)
INFO.regress.greyMatter = 0;
INFO.regress.whiteMatter = .99;
INFO.regress.CSF_bone = .99; %Cerebral Spinal Fluid/Bone
INFO.regress.softTissue = .99;
INFO.regress.air_background = .99;


%% PREPROCESSING STEPS
% Choose what preprocessing steps to complete. Select from 'dicomImport', 
% 'setOrigin', 'despike', 'sliceTime', 'realign', 'coregister', 'segment', 
% 'norm', 'smooth', and 'extractPhysio'. The above is the recommended order 
% though 'sliceTime' and 'realign' are often swapped. (For sequential 
% acquisition: little movement -> realignment first; lots of movement -> 
% slice time first. For interleaved best to not do slice timing BUT it 
% needs to be done for DCM analyses.) 'setOrigin' and 'realign'
% MUST be one of the preprocessing steps and should feature before 
% 'coregister'; 'segment' should be after 'coregister'.
INFO.preprocOrder{1} = 'dicomImport';
%INFO.preprocOrder{end+1} = 'removeTMSartifacts';
INFO.preprocOrder{end+1} = 'setOrigin';
INFO.preprocOrder{end+1} = 'despike';
INFO.preprocOrder{end+1} = 'sliceTime';
INFO.preprocOrder{end+1} = 'realign';
INFO.preprocOrder{end+1} = 'coregister';
INFO.preprocOrder{end+1} = 'segment';
INFO.preprocOrder{end+1} = 'norm';
INFO.preprocOrder{end+1} = 'smooth';
INFO.preprocOrder{end+1} = 'extractPhysio';

% How to append the name of EPI functional images for each step
% It is recommended that these defaults are not changed unless several
% options are explored (e.g., smoothing of both 4 and 8 mm).
INFO.nameAppend.func = 'f';
INFO.nameAppend.tms = 't';
INFO.nameAppend.despike = 'd';
INFO.nameAppend.sliceTime = 'a';
INFO.nameAppend.realign = 'r';
INFO.nameAppend.norm = 'w'; %SPM12 doesn't allow this to be changed
INFO.nameAppend.smooth = 's';
INFO.nameAppend.anat = 'anat';


%% SECOND LEVEL
% Choose the model to estimate in the FIRST LEVEL section. If any
% covariates are required, add this functionality separately.


%% FOLDER ORGANIZATION

% Parent folder (level 1)
INFO.dir.root.name = '/home/despo/rahnev/tmsMRI/Projects/rest1_2_5_10/';

% Folder with MRI (functional and structural) data (level 2)
INFO.dir.root.MRI.name = 'MRI_data';

% Folders with individual subject data (level 3)
% The string defined below should be followed by a number. E.g. define 
% INFO.dir.root.MRI.subj.name as 'sub' and name subject folders "sub1", 
% "sub2", etc. 
INFO.dir.root.MRI.subj.name = 'sub';

% Folder with DICOM data (level 4)
INFO.dir.root.MRI.subj.dicom.name = 'DICOM';

% Folders with EPI data (level 5)
% All folders should start with the string below and folders with other 
% stuff (such as anatomical images or subject info) should not.
INFO.dir.root.MRI.subj.dicom.epi.name = 'run';

% Folder with T1 data (level 5)
INFO.dir.root.MRI.subj.dicom.anat.name = 'anatomical';

% Folder with Physio data (level 5). Folders inside here should have the
% same names as the EPI data folders (usually 'run1', 'run2', etc.)
INFO.dir.root.MRI.subj.dicom.physio.name = 'physio';

% Folder where NIFTI files are to be created and analyzed (level 4)
INFO.dir.root.MRI.subj.nifti.name = 'NIFTI';

% Folder for first level GLM models (level 4)
INFO.dir.root.MRI.subj.first_level.name = 'firstLevelModels';

% Folder with second level models (level 3)
INFO.dir.root.MRI.second_level.name = 'secondLevelModels';

% Folder for analyses (level 2)
INFO.dir.root.analyses.name = 'Analyses';

% Folder with behavioral data (level 3)
INFO.dir.root.analyses.behavData.name = 'behavioralData';


%% EPI INFO AND PREPROCESSING DETAILS
%----------- general information about scan -------------------------------
% TR
INFO.TR = 1.2;

%----------- info for DICOM conversion ------------------------------------
% Number of volumes to remove from beginning of each run
INFO.numVolToRemove = 0;

%----------- info for despiking -------------------------------------------
% Spike thresholds in SD. Defaults: 2.5 and 4.
INFO.spikeDetectThresh = 2.5;
INFO.spikeUpperBound = 4;

%-----------info for smoothing-------------------------------------------
% Smoothing kernel. Usually [6 6 6] or [8 8 8]. For MVPA analyses, set to [0 0 0].
INFO.FWHM = [6 6 6];

%-----------info for saving the preproc steps-----------------------------
INFO.logfileName = 'preprocDone.mat';


%% NO NEED TO CHANGE ANYTHING BELOW THIS LINE
%%--------------------------------------------------------------------------
% Determine expected name of FUNCTIONALS before each step: the variable
% "name" holds the expected file name BEFORE the relevant step
nameString = INFO.nameAppend.func; %baseline name for functionals
INFO.nameAfter.func = nameString;
for step=1:length(INFO.preprocOrder)
    switch INFO.preprocOrder{step}
        case 'removeTMSartifacts'
            INFO.nameBefore.tms = nameString;
            nameString = [INFO.nameAppend.tms nameString];
            INFO.nameAfter.tms = nameString;
        case 'despike'
            INFO.nameBefore.despike = nameString;
            nameString = [INFO.nameAppend.despike nameString];
            INFO.nameAfter.despike = nameString;
        case 'sliceTime'
            INFO.nameBefore.sliceTime = nameString;
            nameString = [INFO.nameAppend.sliceTime nameString];
            INFO.nameAfter.sliceTime = nameString;
        case 'realign'
            INFO.nameBefore.realign = nameString;
            nameString = [INFO.nameAppend.realign nameString];
            INFO.nameAfter.realign = nameString;
        case 'norm'
            INFO.nameBefore.norm = nameString;
            nameString = [INFO.nameAppend.norm nameString];
            INFO.nameAfter.norm = nameString;
        case 'smooth'
            INFO.nameBefore.smooth = nameString;
            nameString = [INFO.nameAppend.smooth nameString];
            INFO.nameAfter.smooth = nameString;
    end
end