%roiAnalyses

% Add path to Marsbar
addpath('/home/rahnev/toolboxes/marsbar/');

%% Build ROIs
% % Anatomical ROIs
% radius = 10;
% peak = [-41, -27, 6];
% region = 'lAuditory';
% name = [region '_' num2str(radius) 'mm'];
% dirToSave = fullfile(INFO.dir.root.name, INFO.dir.root.analyses.name, 'ROIs');
% buildSphereROI(name, peak, radius, dirToSave);


%% Extract betas
roiName = 'lIPS_10mm';
roiFullPath = fullfile(INFO.dir.root.name, INFO.dir.root.analyses.name, 'ROIs', [roiName '_roi.mat']);
for subject=INFO.subjects
    subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
    SPMfullPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subjStr, ...
        INFO.dir.root.MRI.subj.first_level.name, INFO.model, 'SPM.mat');
    betaValuesAll{subject} = extractBetas(roiFullPath, SPMfullPath);
    
    % Load SPM value to check the exact design
    load(SPMfullPath);
    numSess = length(SPM.Sess);
    numEvents = length(SPM.Sess(1).U);
    numTotalRegr = length(SPM.Sess(1).col);
    
    % Compute the mean beta for each event type across all sessions
    for event=1:numEvents
        betaValues(subject,event) = mean(betaValuesAll{subject}(event:numTotalRegr:end-numSess));
    end
end


%% Analyze beta values
betaValues
mean(betaValues)
% figure
% bar(1:12, mean(betaValues))

figure
for subj=1:length(INFO.subjects)
    subplot(2,2,subj)
    bar(1:numEvents, betaValues(subj,:))
end