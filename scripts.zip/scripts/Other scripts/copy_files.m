%copy_files

clear

% The root directory is the stem of all subject directories
source_directory = '//home/despo/rahnev/Gorea/';
destination = '//home/despo/rahnev/Gorea/MRI_data/';

for subject=1:12
    subject_name = ['S' num2str(subject) ''];
    folders = dir(['//home/despo/rahnev/Gorea/' subject_name '/func/run*']);
    
    for folder=1:length(folders)
        
        dest_folder = fullfile(destination, subject_name, folders(folder).name);
        mkdir(dest_folder);
        source_path = fullfile(source_directory, subject_name, 'func', folders(folder).name, 'Preproc');
        source_files = dir([source_path '/func*.nii']);
        
        %Copy the files
        for file=1:length(source_files)
            copyfile(fullfile(source_path,source_files(file).name), dest_folder);
        end
    end
end
