%rename_mt_files

clear

% The root directory is the stem of all subject directories
source_directory = '/home/predatt/dobrah/fluct_detect';

for subject=1:1
    for session=1:2
        subject_name = ['S' num2str(subject) ''];
        source_file_name = ['analysis/ana_localizer/ROIs/sess' num2str(session) '_mdata.mat'];
        destination_file_name = ['analysis/ana_localizer/ROIs/s' num2str(subject) '_mt_sess' num2str(session) '_mdata.mat'];
      
        %Specify the source and destination folders
        source = fullfile(source_directory,subject_name,source_file_name);
        destination = fullfile(source_directory,subject_name,destination_file_name);
        
        %Copy the files
        movefile(source, destination);
    end
end
