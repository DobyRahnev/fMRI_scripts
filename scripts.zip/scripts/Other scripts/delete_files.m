%delete_file

clear

SUBJECT_LIST = {'S1'};
%SUBJECT_LIST = {'S3','S4','S5','S6','S7','S10','S12','S14','S16','S20','S22','S23','S24','S25','S38'};

ROOT_DIR = '//home/despo/rahnev/learningMRI/';

for subject_number=1:length(SUBJECT_LIST)
    subject = SUBJECT_LIST{subject_number};
    
    %Delete the original 3D functional images
        files = dir([ROOT_DIR subject '/f*.nii']);
        for i=1:length(files)
            delete([output_dir '/' files(i).name]);
        end
        
end