function preproc_segment(INFO)

%-------------------------------------------------------------------------
% Performs T1 segmentation for a single subject. Function called from
% preprocManager.m.
%
% Segment produces 5 new images:
% c1* - grey matter
% c2* - white matter
% c3* - CSF, bone
% c4* - soft tissue
% c5* - air/background
%-------------------------------------------------------------------------

% Check whether segmentation was performed already
segmentFiles = dir(fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, 'c5*.nii'));
if ~isempty(segmentFiles)
    disp(['Segmentation requested but it was already performed for subject: ' INFO.subjStr '. Segmentation skipped.']);
    return
end

% Determine the name of the anatomical image
anatFile = dir(fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, [INFO.nameAppend.anat '*.nii']));
if isempty(anatFile)
    disp(['ERROR: Anatomical image not found: ' fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, [INFO.nameAppend.anat '*.nii']) ]);
    disp('Check that DICOM conversion for the anatomical image was performed successfully');
    return
end
anatFileName = fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, anatFile.name);

% Initialize the SPM batch
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');

% Perform segmentation
fprintf(['======\n' 'Performing SEGMENT for subject: ' INFO.subjStr '\n======\n']);
matlabbatch{1}.spm.spatial.preproc.channel.vols = {anatFileName};
spm_jobman('run',matlabbatch);

% Save preprocessing step details
load(INFO.logfile);
preprocDone.segment.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');


%% Reslice images in the functional images space

% Initialize the SPM batch
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');

% Name of functional file from first run
fileName = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, [INFO.nameAppend.func '*.nii']));
fileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, fileName.name);

% Names of files from segment output
for c=1:5
    names{c} = fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, ['c' num2str(c) anatFile.name]);
end

% Perform reslice
matlabbatch{1}.spm.spatial.coreg.write.ref = {[fileName, ',1']}; %give the first volume of the first run
matlabbatch{1}.spm.spatial.coreg.write.source = names;
matlabbatch{1}.spm.spatial.coreg.write.roptions.prefix = 'r';
spm_jobman('run',matlabbatch);