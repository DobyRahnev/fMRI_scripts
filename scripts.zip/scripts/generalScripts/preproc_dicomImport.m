function preproc_dicomImport(INFO)

%-------------------------------------------------------------------------
% This script runs the DICOM import, conversion to a single 4D nii file,
% and renaming of that file. All files named f*.nii will be deleted in the
% destination folder (as part of the clean up).
%
% Parameters used by script:
% dicomPath -- parent folder with DICOMs (each EPI run, as well as the
%       T1 run should be subfolders)
% niftiPath -- parent folder to put nii files in
% INFO.numVolToRemove -- number of volumes to discard at the start of EPI scans.
% cutEnd -- number of volumes to discard at the end of EPI scans. The
%       default is not to cut from end. If you want that, change the value
%       of cutEnd in the script below.
%-------------------------------------------------------------------------

% Do we cut volumes at the end of the scan? (If yes, cutEnd should be a
% vector with the number of volumes for each run)
cutEnd = 'NO';

% Path to DICOM folder
dicomPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, INFO.subjStr, INFO.dir.root.MRI.subj.dicom.name);
if ~exist(dicomPath, 'dir')
    disp(['ERROR: cannot find directory for DICOM images. Directory given: ' dicomPath]);
    return
end

% Check if NIFTI folder is created
if ~exist(INFO.niftiPath, 'dir')
    success = mkdir(INFO.niftiPath);
    if ~success
        disp(['ERROR: failed to make directory for the NIFTI files. Directory given: ' INFO.niftiPath '.  Check permissions.']);
        return
    end
end

% Find out the names and number of EPI subfolders
epiFolderInfo = dir(fullfile(dicomPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
folderNames = {epiFolderInfo.name}';
numEpiRuns = length(folderNames);
if numEpiRuns == 0
    disp(['No EPI subfolders found in parent folder: ' dicomPath '!!!']);
    disp('DICOM conversion aborted');
    return
end

% Check whether DICOM import was performed already
niftiFiles = dir(fullfile(INFO.niftiPath, folderNames{1}, [INFO.nameAppend.func '*.nii']));
if ~isempty(niftiFiles)
    disp(['DICOM import requested but it was already performed for subject: ' INFO.subjStr '. DICOM import skipped.']);
    return
end

% Find out if T1 subfolder exists
if exist(fullfile(dicomPath, INFO.dir.root.MRI.subj.dicom.anat.name), 'dir')
    folderNames{end+1} = INFO.dir.root.MRI.subj.dicom.anat.name;
    numAnatRuns = 1;
else
    numAnatRuns = 0;
end

% If NIFTI files are already in the folder, then don't run this script
if ~isempty(dir(fullfile(INFO.niftiPath, folderNames{1}, [INFO.nameAppend.func '*.nii'])))
    disp('DICOM files appear to be already converted to NIFTI.');
    disp('DICOM conversion aborted');
    return
end

fprintf(['======\n' 'Performing DICOM IMPORT for subject: ' INFO.subjStr '\n======\n']);

% Go through all EPI runs
for run = 1:numEpiRuns+numAnatRuns
    
    %% IMPORT DICOMS
    % Grab all files for this run
    dcm_folder = fullfile(dicomPath, folderNames{run});
    all_files = dir(fullfile(dcm_folder, '*.dcm'));
    if isempty(all_files)
        disp(['No DICOMs found in folder: ' folderNames{run} '!']);
        disp('DICOMs need to be placed directly in the folder and not in subfolders!');
    end
    
    % Figure out which volumes to import
    if run <= numEpiRuns %for EPI runs, consider cutting from start and end
        firstVolume = INFO.numVolToRemove + 1;
        if strcmp(cutEnd,'NO')
            lastVolume = length(all_files);
        else
            lastVolume = length(all_files) - cutEnd(epiRuns);
        end
    else %for T1, don't cut anything
        firstVolume = 1;
        lastVolume = length(all_files);
    end
    
    toImport = [];
    for i = firstVolume:lastVolume
        file_name = all_files(i).name;
        toImport = [toImport; fullfile(dcm_folder, file_name)];
    end
    
    % Create output folder (with the same name as in DICOM folder)
    output = fullfile(INFO.niftiPath, folderNames{run});
    if ~exist(output, 'dir')
        success = mkdir(output);
        if ~success
            disp(['Error: failed to create directory. Directory given: ' output '.  Check permissions.']);
            return
        end
    end
    
    % Initialize SPM batch
    clear matlabbatch
    spm('defaults', 'fmri');
    spm_jobman('initcfg');
    
    % Do DICOM import for current run
    fprintf(['======\nConverting DICOMs from folder: ' folderNames{run} '\n======\n']);
    matlabbatch{1}.spm.util.import.dicom.data = cellstr(toImport);
    matlabbatch{1}.spm.util.import.dicom.outdir = {output};
    spm_jobman('run',matlabbatch);
    
    
    %% Combine the 3D files into a single 4D file and clean up
    nii_files = fullfile(output, '*.nii');
    % Decide on the 4D file name depending on whether it's EPI or T1
    if run <= numEpiRuns %for EPI runs
        name_4D_file = [INFO.nameAppend.func '_' INFO.subjStr '_' folderNames{run} '.nii'];
    else
        name_4D_file = [INFO.nameAppend.anat '_' INFO.subjStr '.nii'];
    end
    fprintf(['======\n' 'Creating 4D file and removing 3D files in folder: ' folderNames{run} '\n======\n']);
    system(['fslmerge -t ' fullfile(output,name_4D_file) ' ' nii_files]);
    
    %Delete the original 3D functional images and any other old nifti files (but not the 4D)
    files = dir(fullfile(output, '*.nii'));
    for i=1:length(files)
        delete(fullfile(output, files(i).name));
    end
    
    %Unzip the 4D file (AFNI creates it zipped)
    gunzip(fullfile(output, [name_4D_file '.gz']));
    delete(fullfile(output, [name_4D_file '.gz']));
end

%% Save preprocessing step details in folder with subjects
% Delete previous versions of the preprocessing log
if exist(INFO.logfile, 'file')
    delete(INFO.logfile);
end
preprocDone.readme = ['Details related to each preprocessing step will be saved here. Note that only the last version '...
    'of the variable INFO is saved here, which may not reflect what was used on earlier steps'];
preprocDone.dicomImport.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');