function signal = computeGlobalSignal(epiData, anatDir, componentNum, threshold)
%-------------------------------------------------------------------------
% Computes the global signals for segmentation components.
%
% Function called from firstLevel.m.
%-------------------------------------------------------------------------

% Load relevant component from segmentation (resliced to functional space)
file = dir(fullfile(anatDir, ['c' num2str(componentNum) '*.nii']));
volumeInfo = spm_vol(fullfile(anatDir,file.name));
T1component = spm_read_vols(volumeInfo);

% Go through each volume of the EPI data and compute the average signal
% from the component
for volume=1:size(epiData,4)
    data = epiData(:,:,:,volume);
    signal(volume) = mean(data(T1component >= threshold));
end