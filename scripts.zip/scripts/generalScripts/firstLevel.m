function firstLevel(INFO)

%-------------------------------------------------------------------------
% Computes standard first level GLM model.
%
% This file is to be called from run_scripts.m which controls what
% processing steps to run.
%-------------------------------------------------------------------------

% Loop through subjects
for subject=INFO.subjects
    
    % Determine names and paths
    subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
    subjPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subjStr);
    niftiPath = fullfile(subjPath, INFO.dir.root.MRI.subj.nifti.name);
    first_levelPath = fullfile(subjPath, INFO.dir.root.MRI.subj.first_level.name);
    modelPath = fullfile(first_levelPath, INFO.model);
    
    % Check if folder for first level models is created
    if ~exist(first_levelPath, 'dir')
        mkdir(first_levelPath);
    end
    if ~exist(modelPath, 'dir')
        mkdir(modelPath);
    end
    
    % Remove previous SPM files
    spm_file = fullfile(first_levelPath,'SPM.mat');
    if exist(spm_file,'file')==2
        delete(spm_file);
    end
    
    % Initialize the SPM batch
    clear matlabbatch
    spm('defaults', 'fmri');
    spm_jobman('initcfg');
    
    % Determine info for batch that is run-independent
    matlabbatch{1}.spm.stats.fmri_spec.dir = {modelPath};
    matlabbatch{1}.spm.stats.fmri_spec.timing.units = INFO.units;
    matlabbatch{1}.spm.stats.fmri_spec.timing.RT = INFO.TR;
    
    % Determine the names and number of EPI subfolders
    epiFolderInfo = dir(fullfile(niftiPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
    epiFolderNames = {epiFolderInfo.name}';
    numEpiRuns = length(epiFolderNames);
    
    % Determine the run names
    if iscell(INFO.modelRuns{1})
        % Each subject with individually defined runs
        runs = INFO.modelRuns{subject};
    else
        % All subjects have the same runs
        runs = INFO.modelRuns;
    end
    
    % Loop through all runs
    for run_num=1:length(runs)
        runName = runs{run_num};
        
        % Determine the names, onsets, and durations of the events (unless
        % defining a PPI model)
        if ~strcmp(INFO.model(1:3), 'PPI')
            events = setOnsets(INFO, INFO.model, subjStr, runName);
        end
        
        % Determine the name of the 4D file to use
        nameAppended = eval(['INFO.nameAfter.' INFO.preprocOrder{end}]);
        fileForFirstLevel = dir(fullfile(niftiPath, runName, [nameAppended '*.nii']));
        if isempty(fileForFirstLevel)
            disp(['ERROR: File for first level model not found: ' fullfile(niftiPath, runName, [nameAppended '*.nii']) ]);
            disp('Tried to use the file from the last preprocessing step from INFO.preprocOrder');
            return
        end
        fileName = fullfile(niftiPath, runName, fileForFirstLevel.name);
        
        % Determine the number of volumes in the 4D file
        volumeInfo = spm_vol(fileName);
        numVolumes = length(volumeInfo);
        if any([INFO.regress.greyMatter INFO.regress.whiteMatter INFO.regress.CSF_bone INFO.regress.softTissue INFO.regress.air_background])
            epiData = spm_read_vols(volumeInfo);
        end
        
        % Concatenate all individual volumes from the 4D file
        filesForModel = [];
        for volume=1:numVolumes
            filesForModel = strvcat(filesForModel, [fileName ',' num2str(volume)]);
        end
        
        % Load the motion regressors
        motionFile = dir(fullfile(niftiPath, runName, 'rp_*.txt'));
        if isempty(motionFile)
            disp(['ERROR: Motion regressors not found: ' fullfile(niftiPath, runName, 'rp_*.txt') ]);
            return
        end
        motionParams = load(fullfile(niftiPath, runName, motionFile.name));
        motionParams(:,4:6) = (motionParams(:,4:6).*180)./pi; %change from radians to degrees for ease of interpretability
        
        % Decide which motion parameters to include
        regressors = [];
        regressorName = [];
        if INFO.motion.raw
            regressors = [regressors, motionParams];
            regressorName = [regressorName {'MovX','MovY','MovZ','Pitch','Roll','Yaw'}];
        end
        if INFO.motion.squared
            regressors = [regressors, motionParams.^2];
            regressorName = [regressorName {'X_Sq','Y_Sq','Z_Sq','Pitch_Sq','Roll_Sq','Yaw_Sq'}];
        end
        if INFO.motion.firstDerivative
            regressors = [regressors, [zeros(1,6); diff(motionParams)]];
            regressorName = [regressorName {'X_1stDer','Y_1stDer','Z_1stDer','Pitch_1stDer','Roll_1stDer','Yaw_1stDer'}];
        end
        if INFO.motion.secondDerivative
            regressors = [regressors, [zeros(2,6); diff(motionParams,2)]];
            regressorName = [regressorName {'X_2ndDer','Y_2ndDer','Z_2ndDer','Pitch_2ndDer','Roll_2ndDer','Yaw_2ndDer'}];
        end
        
        % Decide which global signals to include
        if INFO.regress.greyMatter > 0
            signal = computeGlobalSignal(epiData, fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name), 1, INFO.regress.greyMatter);
            regressors = [regressors, signal'];
            regressorName = [regressorName {'greyMatter'}];
        end
        if INFO.regress.whiteMatter > 0
            signal = computeGlobalSignal(epiData, fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name), 2, INFO.regress.whiteMatter);
            regressors = [regressors, signal'];
            regressorName = [regressorName {'whiteMatter'}];
        end
        if INFO.regress.CSF_bone > 0
            signal = computeGlobalSignal(epiData, fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name), 3, INFO.regress.CSF_bone);
            regressors = [regressors, signal'];
            regressorName = [regressorName {'CSF_bone'}];
        end
        if INFO.regress.softTissue > 0
            signal = computeGlobalSignal(epiData, fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name), 4, INFO.regress.softTissue);
            regressors = [regressors, signal'];
            regressorName = [regressorName {'softTissue'}];
        end
        if INFO.regress.air_background > 0
            signal = computeGlobalSignal(epiData, fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name), 5, INFO.regress.air_background);
            regressors = [regressors, signal'];
            regressorName = [regressorName {'air_background'}];
        end
        
        % Load the physio regressors
        physioPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, INFO.subjStr, INFO.dir.root.MRI.subj.dicom.name, INFO.dir.root.MRI.subj.dicom.physio.name);
        physioFile = fullfile(physioPath, runName, 'physio_regressors.txt');
        if exist(physioFile, 'file')
            fprintf(['Warning: no physio regressors found for subject: ' num2str(subject) ', run: ' num2str(run_num) ...
                '. Continuing without including physio regressors.\n']);
        else
            physioParams = load(physioFile);
            fprintf(['Including ' num2str(size(physioParams,1)) ' physio parameters.\n']);
            regressors = [regressors, physioParams];
            for num_physReg=1:size(physioParams,1)
                regressorName = [regressorName {['Phys' num2str(num_physReg)]}];
            end
        end
        
        % Put all info into batch
        matlabbatch{1}.spm.stats.fmri_spec.sess(run_num).scans = cellstr(filesForModel);
        
        % Define the names, onsets, and durations
        if exist('events', 'var')
            for event=1:length(events.names)
                matlabbatch{1}.spm.stats.fmri_spec.sess(run_num).cond(event).name = events.names{event};
                matlabbatch{1}.spm.stats.fmri_spec.sess(run_num).cond(event).onset = events.onsets{event};
                matlabbatch{1}.spm.stats.fmri_spec.sess(run_num).cond(event).duration = events.durations{event};
            end
        end
        
        % Include regressors defined above (e.g., motion and tissues)
        for i=1:length(regressorName)
            matlabbatch{1}.spm.stats.fmri_spec.sess(run_num).regress(i).name = regressorName{i};
            matlabbatch{1}.spm.stats.fmri_spec.sess(run_num).regress(i).val = regressors(:,i);
        end
        
        % Add multiple regressors (currently, only used for PPI analyses)
        if strcmp(INFO.model(1:3), 'PPI')
            matlabbatch{1}.spm.stats.fmri_spec.sess(run_num).multi_reg = INFO.multi_reg{run_num};
        end
    end
    
    % Run the batch
    fprintf(['======\n' 'SPECIFYING FIRST LEVEL for subject: ' subjStr ', model: ' INFO.model '\n======\n']);
    spm_jobman('run',matlabbatch);
    
    
    %% Estimate the model
    % Initialize new SPM batch
    clear matlabbatch
    spm('defaults', 'fmri');
    spm_jobman('initcfg');
    
    % Run the batch
    matlabbatch{1}.spm.stats.fmri_est.spmmat = {fullfile(modelPath,'SPM.mat')};
    fprintf(['======\n' 'ESTIMATING FIRST LEVEL for subject: ' subjStr ', model: ' INFO.model '\n======\n']);
    spm_jobman('run',matlabbatch);
    
    
    %% Contrast Generator
    % Define the contrasts
    contrasts = setContrasts(INFO.model, length(regressorName), length(runs));
    
    % Initialize new SPM batch
    clear matlabbatch
    spm('defaults', 'fmri');
    spm_jobman('initcfg');
    
    % Put contrast info in the batch
    for c=1:length(contrasts.name)
        matlabbatch{1}.spm.stats.con.consess{c}.tcon.name = contrasts.name{c};
        matlabbatch{1}.spm.stats.con.consess{c}.tcon.convec = contrasts.formula{c};
        matlabbatch{1}.spm.stats.con.consess{c}.tcon.sessrep = 'none';
    end
    
    % Delete the current contrasts
    matlabbatch{1}.spm.stats.con.delete = 1;
    matlabbatch{1}.spm.stats.con.spmmat = {fullfile(modelPath,'SPM.mat')};
    
    % Run the job: make the contrasts
    fprintf(['======\n' 'MAKING CONTRASTS for subject: ' subjStr ', model: ' INFO.model '\n======\n']);
    spm_jobman('run',matlabbatch);
    
end