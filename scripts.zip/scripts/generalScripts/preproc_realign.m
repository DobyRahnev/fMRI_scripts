function preproc_realign(INFO)

%-------------------------------------------------------------------------
% Performs realigning for a single subject. Function called from
% preprocManager.m.
%-------------------------------------------------------------------------

% Check whether realign and reslice was performed already
realignedFiles = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, [INFO.nameAfter.realign '*.nii']));
if ~isempty(realignedFiles)
    disp(['Realigning requested but it was already performed for subject: ' INFO.subjStr '. Realign skipped.']);
    return
end

% Determine the names of the files to realign
for run = 1:INFO.numEpiRuns
    % Determine the name of the 4D file to realign
    filePreviousStep = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.realign '*.nii']));
    if isempty(filePreviousStep)
        disp(['ERROR: File for realignment not found: ' fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.realign '*.nii']) ]);
        disp('Check that the previous preprocessing step in INFO.preprocOrder was completed');
        return
    end
    fileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, filePreviousStep.name);
    
    % Determine the number of volumes in the 4D file
    volumeInfo = spm_vol(fileName);
    numVolumes = length(volumeInfo);
    
    % Concatenate all individual volumes from the 4D file
    for volume=1:numVolumes
        filesToRealign{run}{volume,1} = [fileName, ',' num2str(volume)];
    end
end

% Initialize the SPM batch
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');

% Perform REALIGN AND RESLICE
fprintf(['======\n' 'Performing REALIGN AND RESLICE for subject: ' INFO.subjStr '\n======\n']);
matlabbatch{1}.spm.spatial.realign.estwrite.data = filesToRealign;
matlabbatch{1}.spm.spatial.realign.estwrite.roptions.prefix = INFO.nameAppend.realign;
%matlabbatch{1}.spm.spatial.realignunwarp.data.scans = filesToRealign;
%matlabbatch{1}.spm.spatial.realignunwarp.uwroptions.prefix = 'u';
spm_jobman('run',matlabbatch);

% Save preprocessing step details
load(INFO.logfile);
preprocDone.realign.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');