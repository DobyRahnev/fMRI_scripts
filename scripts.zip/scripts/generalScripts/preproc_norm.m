function preproc_norm(INFO)

%-------------------------------------------------------------------------
% Normalizes the T1 and EPI image for a single subject. Function
% called from preprocManager.m.
%
% Function uses the NORMALISE AND RESLICE option in SPM12.
%-------------------------------------------------------------------------

% Check whether normalization was performed already
normalisedFiles = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, [INFO.nameAfter.norm '*.nii']));
if ~isempty(normalisedFiles)
    disp(['Normalisation requested but it was already performed for subject: ' INFO.subjStr '. Normalisation skipped.']);
    return
end

% Determine the name of the anatomical image
anatFile = dir(fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, [INFO.nameAppend.anat '*.nii']));
if isempty(anatFile)
    disp(['ERROR: Anatomical image not found: ' fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, [INFO.nameAppend.anat '*.nii']) ]);
    disp('Check that DICOM conversion for the anatomical image was performed successfully');
    return
end
anatFileName = fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, anatFile.name);

% Determine the names of the EPI files to normalise
filesToNormalise = [];
for run = 1:INFO.numEpiRuns
    % Determine the name of the 4D file to normalise
    filePreviousStep = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.norm '*.nii']));
    if isempty(filePreviousStep)
        disp(['ERROR: Files for normalisation not found: ' fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.norm '*.nii']) ]);
        disp('Check that the previous preprocessing step in INFO.preprocOrder was completed');
        return
    end
    fileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, filePreviousStep.name);
    
    % Determine the number of volumes in the 4D file
    volumeInfo = spm_vol(fileName);
    numVolumes = length(volumeInfo);
    
    % Concatenate all individual volumes from the 4D file
    for volume=1:numVolumes
        filesToNormalise{end+1,1} = [fileName ',' num2str(volume)];
    end
end

% Add the T1 image + segmentation images for normalisation
filesToNormalise{end+1} = anatFileName;
for imageClass=1:5
    filesToNormalise{end+1} = fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, ['c' num2str(imageClass) anatFile.name]);
end

% Initialize the SPM batch
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');

% Perform normalise
fprintf(['======\n' 'Performing NORMALISE for subject: ' INFO.subjStr '\n======\n']);
matlabbatch{1}.spm.spatial.normalise.estwrite.subj.vol = {anatFileName};
matlabbatch{1}.spm.spatial.normalise.estwrite.subj.resample = filesToNormalise;
spm_jobman('run',matlabbatch);

% Save preprocessing step details
load(INFO.logfile);
preprocDone.norm.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');