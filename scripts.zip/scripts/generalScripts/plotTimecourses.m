function plotTimecourses(INFO, preprocStep)

%-------------------------------------------------------------------------
% Plots time courses for each slice for the data from
% the specified preprocessing step (e.g., plotTimecourses(INFO, 'func'));
%
% Function called from run_scripts.m.
%-------------------------------------------------------------------------

% Loop through all subjects
for subject=INFO.subjects
    
    % Determine the names and number of EPI subfolders
    niftiPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, ...
        [INFO.dir.root.MRI.subj.name num2str(subject)], INFO.dir.root.MRI.subj.nifti.name);
    epiFolderInfo = dir(fullfile(niftiPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
    epiFolderNames = {epiFolderInfo.name}';
    numEpiRuns = length(epiFolderNames);
    
    % Go through each EPI folder
    for run = 1:numEpiRuns
        
        %% Plot time courses
        if ~isfield(INFO.nameAfter, preprocStep)
            Error('Unrecognized preprocessing step. Set the second parameter in plotTimecourses.m to func, despike, sliceTime, realign, norm, or smooth');
        else
            % Determine the file to plot data from
            nameAppend = eval(['INFO.nameAfter.' preprocStep]);
            file = dir(fullfile(niftiPath, epiFolderNames{run}, [nameAppend '*.nii']));
            if isempty(file)
                error(['Files for plotting not found. Requested file name: ' fullfile(niftiPath, epiFolderNames{run}, nameAppend) '*.nii']);
            end
            functionalData = fullfile(niftiPath, epiFolderNames{run}, file.name);
            
            % Load the data and determine #slices and #volumes
            dataBlock_V = spm_vol(functionalData);
            dataBlock = spm_read_vols(dataBlock_V);
            numSlices = size(dataBlock,3);
            numVolumes = size(dataBlock,4);
            
            % Compute mean across the entire slice
            epiMeanSlices = mean(mean(dataBlock,2),1);
            epiMeanSlices = reshape(epiMeanSlices,numSlices,numVolumes);
            
            % Plot time courses
            figure;
            plotDim1 = ceil(sqrt(numSlices+1));
            plotDim2 = ceil((numSlices+1)/plotDim1);
            subplot(plotDim1,plotDim2,1);
            plot(1:numVolumes,mean(epiMeanSlices), 'r');
            xlim([0 numVolumes+1]);
            title('Average whole brain', 'FontSize', 15);
            for sliceIdx = 1:numSlices
                subplot(plotDim1,plotDim2,sliceIdx+1);
                plot(1:numVolumes,epiMeanSlices(sliceIdx,:), 'k');
                xlim([0 numVolumes+1]);
                title(['Slice number ' num2str(sliceIdx)]);
            end
            set(gcf,'Units','pixels','Position',[0 0 9999 9999]); %make figure maximally large
        end
    end
end