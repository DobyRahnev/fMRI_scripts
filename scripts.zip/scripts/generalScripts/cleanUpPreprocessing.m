function cleanUpPreprocessing(INFO, data)

%-------------------------------------------------------------------------
% Deletes intermediate steps from the preprocessing stream.
%
% Function called from run_scripts.m.
%-------------------------------------------------------------------------

% Loop through all subjects
for subject=INFO.subjects
    
    % Determine the names and number of EPI subfolders
    niftiPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, ...
        [INFO.dir.root.MRI.subj.name num2str(subject)], INFO.dir.root.MRI.subj.nifti.name);
    epiFolderInfo = dir(fullfile(niftiPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
    epiFolderNames = {epiFolderInfo.name}';
    numEpiRuns = length(epiFolderNames);
    
    % Go through each EPI folder and delete unwanted files
    for run = 1:numEpiRuns
        
        % Determine all files associated with each preprocessing step
        files = [];
        for preprocStep=1:length(data)
            switch data{preprocStep}
                case 'func'
                    files = [files; dir(fullfile(niftiPath, epiFolderNames{run}, ...
                        [INFO.nameAppend.func '*.*']))];
                case 'despike'
                    files = [files; dir(fullfile(niftiPath, epiFolderNames{run}, ...
                        [INFO.nameAfter.despike '*.*']))];
                case 'sliceTime'
                    files = [files; dir(fullfile(niftiPath, epiFolderNames{run}, ...
                        [INFO.nameAfter.sliceTime '*.*']))];
                case 'realign'
                    files = [files; dir(fullfile(niftiPath, epiFolderNames{run}, ...
                        [INFO.nameAfter.realign '*.*']))];
                case 'norm'
                    files = [files; dir(fullfile(niftiPath, epiFolderNames{run}, ...
                        [INFO.nameAfter.norm '*.*']))];
                case 'smooth'
                    files = [files; dir(fullfile(niftiPath, epiFolderNames{run}, ...
                        [INFO.nameAfter.smooth '*.*']))];
            end
        end
        
        % Delete the files for this run
        for i=1:length(files)
            delete(fullfile(niftiPath, epiFolderNames{run}, files(i).name));
        end
    end
end