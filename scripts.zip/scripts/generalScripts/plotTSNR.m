function plotTSNR(INFO, preprocStep, runs, runToDisplay)

%-------------------------------------------------------------------------
% Plots time courses for each slice for the data from
% the specified preprocessing step (e.g., plotTSNR(INFO, 'func'));
%
% Function called from run_scripts.m.
%-------------------------------------------------------------------------

% Loop through all subjects
for subject=INFO.subjects
    
    % Determine the names and number of EPI subfolders
    niftiPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, ...
        [INFO.dir.root.MRI.subj.name num2str(subject)], INFO.dir.root.MRI.subj.nifti.name);
    epiFolderInfo = dir(fullfile(niftiPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
    epiFolderNames = {epiFolderInfo.name}';
    numEpiRuns = length(epiFolderNames);
    
    % Go through each EPI folder
    for run = runs
        
        % Check if the data exist
        if ~isfield(INFO.nameAfter, preprocStep)
            Error('Unrecognized preprocessing step. Set the second parameter in plotTimecourses.m to func, despike, sliceTime, realign, norm, or smooth');
        else
            % Determine the file name
            nameAppend = eval(['INFO.nameAfter.' preprocStep]);
            file = dir(fullfile(niftiPath, epiFolderNames{run}, [nameAppend '*.nii']));
            if isempty(file)
                error(['Files for tSNR estimation not found. Requested file name: ' fullfile(niftiPath, epiFolderNames{run}, nameAppend) '*.nii']);
            end
            functionalData = fullfile(niftiPath, epiFolderNames{run}, file.name);
            
            % Load the data
            headerInfo = spm_vol(functionalData);
            epiData = spm_read_vols(headerInfo);
            
            % Compute tSNR
            signal = mean(epiData,4);
            noise = std(epiData,[],4);
            tsnr = signal./noise;
            
            % Write new file
            headerNew = headerInfo(1);
            tsnr_file_name = fullfile(niftiPath, epiFolderNames{run}, 'tSNR.nii');
            headerNew.fname = tsnr_file_name;
            headerNew.private.dat.fname = tsnr_file_name;
            spm_write_vol(headerNew, tsnr);
            
            % Display the image
            if run==runToDisplay
                spm_image('Display',tsnr_file_name);
            end
            
            % Print out the average tSNR
            fprintf(['\nAverage tSNR for run ' num2str(run) ': ' num2str(nanmean(nanmean(nanmean(tsnr)))) '\n']);
        end
    end
end