function preproc_coregister(INFO)

%-------------------------------------------------------------------------
% Coregisters the T1 to the mean EPI image for a single subject. Function 
% called from preprocManager.m.
%
% In the current version, the function only coregisters the original
% anatomical image. If segmentation is done before coregistration, will
% need to re-write parts of this function to coregister the different
% tissue types too.
%-------------------------------------------------------------------------

% Check whether corregistration was performed already
load(INFO.logfile);
if isfield(preprocDone, 'coregister')
    disp(['Coregistration requested but it was already performed for subject: ' INFO.subjStr '. Coregistration skipped.']);
    return
end

% Determine the name of the anatomical image
anatFile = dir(fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, [INFO.nameAppend.anat '*.nii']));
if isempty(anatFile)
    disp(['ERROR: Anatomical image not found: ' fullfile(INFO.niftiPath, INFO.anatDir, [INFO.nameAppend.anat '*.nii']) ]);
    disp('Check that DICOM conversion for the anatomical image was performed successfully');
    return
end
anatFileName = fullfile(INFO.niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, anatFile.name);

% Determine the name of the mean EPI image
meanEpiFile = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, 'mean*.nii'));
if isempty(meanEpiFile)
    disp(['ERROR: Mean EPI image not found: ' fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, 'mean*.nii') ]);
    disp('Check that realignment was performed. If you do not want to perform realignment, then change preproc_coregister.m to have coregistration use one of the available EPI slices (not the mean).');
    return
end
meanEpiFile = fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, meanEpiFile.name);

% Initialize the batch
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');

% Perform coregistration
fprintf(['======\n' 'Performing COREGISTER for subject: ' INFO.subjStr '\n======\n']);
matlabbatch{1}.spm.spatial.coreg.estimate.ref = {meanEpiFile};
matlabbatch{1}.spm.spatial.coreg.estimate.source = {anatFileName};
spm_jobman('run',matlabbatch);

% Save preprocessing step details
load(INFO.logfile);
preprocDone.coregister.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');