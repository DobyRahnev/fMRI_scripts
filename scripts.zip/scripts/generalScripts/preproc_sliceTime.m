function preproc_sliceTime(INFO)

%-------------------------------------------------------------------------
% Performs slice time correction for a single subject. Function called from
% preprocManager.m.
%-------------------------------------------------------------------------

% Check whether slice timing was performed already
sliceTimeFiles = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, [INFO.nameAfter.sliceTime '*.nii']));
if ~isempty(sliceTimeFiles)
    disp(['Slice timing requested but it was already performed for subject: ' INFO.subjStr '. Slice timing skipped.']);
    return
end

% Determine the names of the files to slice time
for run = 1:INFO.numEpiRuns
    % Determine the name of the 4D file to slice time
    filePreviousStep = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.sliceTime '*.nii']));
    if isempty(filePreviousStep)
        disp(['ERROR: File for slice timing not found: ' fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.sliceTime '*.nii']) ]);
        disp('Check that the previous preprocessing step in INFO.preprocOrder was completed');
        return
    end
    fileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, filePreviousStep.name);
    
    % Determine the number of volumes in the 4D file
    volumeInfo = spm_vol(fileName);
    numVolumes = length(volumeInfo);
    
    % Concatenate all individual volumes from the 4D file
    for volume=1:numVolumes
        filesToSliceTime{run}{volume,1} = [fileName ',' num2str(volume)];
    end
end

% Get info about slice timing from the header of first DICOM file in first folder
folderPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, INFO.subjStr, INFO.dir.root.MRI.subj.dicom.name, INFO.epiFolderNames{1});
all_files = dir(fullfile(folderPath, '*.dcm'));
hdr = spm_dicom_headers(fullfile(epiFolderPath,all_files(1).name));
num_slices = hdr{1}.Private_0019_100a;
TR = hdr{1}.RepetitionTime/1000;
slice_times = hdr{1}.Private_0019_1029;

% Check if TR is consistent with what was specified in study_info.m
if TR ~= INFO.TR
    error(['TR specified in study_info.m (' num2str(INFO.TR) ') differs from TR read in DICOM header (' num2str(TR) ').']);
end

% Initialize the SPM batch
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');

% Perform slice time correction
fprintf(['======\n' 'Performing SLICE TIMING for subject: ' INFO.subjStr '\n======\n']);
matlabbatch{1}.spm.temporal.st.scans = filesToSliceTime;
matlabbatch{1}.spm.temporal.st.nslices = num_slices;
matlabbatch{1}.spm.temporal.st.tr = TR;
matlabbatch{1}.spm.temporal.st.ta = 0; %set to 0 if slice order is in ms
matlabbatch{1}.spm.temporal.st.so = slice_times; %in ms
matlabbatch{1}.spm.temporal.st.refslice = 0; %set in ms if slice order above is also in ms
matlabbatch{1}.spm.temporal.st.prefix = INFO.nameAppend.sliceTime;
spm_jobman('run',matlabbatch);

% Save preprocessing step details
load(INFO.logfile);
preprocDone.sliceTime.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');