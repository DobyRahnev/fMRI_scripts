function Y = extract_raw_timecourses(roiFullPath, directory)

%---------------------------------
% Inputs:
% - roiFullPath: the full path of the ROI
% - directory: the folder where all .nii files should be (no other .nii
% files should be in that folder). Alternatively, instead of the .nii
% files, it is possible to select the relevant SPM.mat file.
%
% Outputs: Y (the timecourse)
%---------------------------------

%% Standard check ups
% Start marsbar to make sure spm_get works
marsbar('on')

% Set up the SPM defaults, just in case
spm('defaults', 'fmri');

%% Extract the timecourses
rois = maroi('load_cell', roiFullPath);  % make maroi ROI objects

% Extract data into marsy data object
if strcmp(directory(end-6:end), 'SPM.mat')
    P = mardo(des_path);  % make mardo design object
else
    P = spm_get('Files', directory, '*.nii');
end

% Get summary time course(s); One can use 'mean', 'median',
% 'eig1', 'wtmean' as the summary function
mY = get_marsy(rois{:}, P, 'mean');  
Y = summary_data(mY);