function [betaValues, contrastValues] = extractBetas(roiFullPath, SPMfullPath)

%% Standard check ups
% Start marsbar to make sure spm_get works
marsbar('on')

% Set up the SPM defaults, just in case
spm('defaults', 'fmri');


%% Extract betas

% Define the ROI
roi = maroi(roiFullPath);

% Make marsbar design object
D = mardo(SPMfullPath);

% Extract data (Fetch data into marsbar data object)
Y = get_marsy(roi, D, 'mean');

% Get contrasts from original design
xCon = get_contrasts(D);

% MarsBaR estimation from the ROI
E = estimate(D, Y);

% Put contrasts from original design back into design object
E = set_contrasts(E, xCon);

% Compute betas
betaValues = betas(E);

% Get stats for all contrasts
contrastValues = compute_contrasts(E, 1:length(xCon));