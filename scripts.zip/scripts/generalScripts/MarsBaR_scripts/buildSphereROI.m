function buildSphereROI(roiName, peak, radius, dirToSave)

%% Standard check ups
% Start marsbar to make sure spm_get works
marsbar('on')

% Set up the SPM defaults, just in case
spm('defaults', 'fmri');


%% Build the ROI
% Make a sphere ROI
roi.centre = peak;
roi.radius = radius;
roi_sphere = maroi_sphere(roi);

% Save ROI as MarsBaR ROI file
saveroi(roi_sphere, fullfile(dirToSave, [roiName '_roi.mat']));

% Save ROI as .nii image
save_as_image(roi_sphere, fullfile(dirToSave, [roiName '.nii']));
