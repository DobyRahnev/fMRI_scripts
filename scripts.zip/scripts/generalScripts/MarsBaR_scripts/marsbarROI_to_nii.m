function marsbarROI_to_nii(roiFullName, newName, dirToSave)

% Load ROI
load(roiFullName)

% Save the ROI as .nii image
save_as_image(roi_sphere, fullfile(dirToSave, [newName '.nii']));
