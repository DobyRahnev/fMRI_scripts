function combineROIs(roisToCombine, roiName, dirToSave)

%% Standard check ups
% Start marsbar to make sure spm_get works
marsbar('on')

% Set up the SPM defaults, just in case
spm('defaults', 'fmri');


%% Combine the ROIs
currentDir = pwd;

newROI = roisToCombine{1};
for i=2:length(roisToCombine)
    newROI = newROI & roisToCombine{i};
end
newROI = label(newROI, roiName); %????

% Go to directory where to images should be saved
eval(['cd ' dirToSave]);
saveroi(newROI, roiName);

% Return to current directory
eval(['cd ' currentDir]);
