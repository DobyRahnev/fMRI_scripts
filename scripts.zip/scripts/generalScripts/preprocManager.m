function preprocManager(INFO)

%-------------------------------------------------------------------------
% This script calls all requested preprocessing steps for the selected
% subjects. The scripts check which preprocessing steps were performed and
% do not repeat anything that was already done (only applies for
% cases in which intermediate steps are saved). Nevertheless, it's
% recommended that all preprocessing steps are performed at once.
%
% Function called from run_scripts.m.
%-------------------------------------------------------------------------

%% Figure out job order
% Make sure that INFO.preprocJobs is a cell structure
if ~iscell(INFO.preprocJobs)
    disp('ERROR: The variable "jobs" should be a cell object with each job in a separate cell')
    return
end

% Make sure that 'setOrigin' is one of the fields in INFO.preprocOrder
positionOfsetOrigin = find(ismember(INFO.preprocOrder, 'setOrigin'));
if isempty(positionOfsetOrigin)
    disp('ERROR: Need to specify "setOrigin" as one of the preprocessing steps in INFO.preprocOrder')
    return
end

% Specify explicitly the jobs if PRE_setOrigin or POST_setOrigin were chosen
if strcmp(INFO.preprocJobs{1}, 'PRE_setOrigin')
    INFO.preprocJobs = INFO.preprocOrder(1:positionOfsetOrigin);
elseif strcmp(INFO.preprocJobs{1}, 'POST_setOrigin')
    INFO.preprocJobs = INFO.preprocOrder(positionOfsetOrigin+1:length(INFO.preprocOrder));
end

%% LOOP THROUGH ALL SUBJECTS AND DO PREPROCESSING JOBS
for subject=INFO.subjects
    
    % Determine names and paths
    INFO.subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
    INFO.niftiPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, INFO.subjStr, INFO.dir.root.MRI.subj.nifti.name);
    INFO.logfile = fullfile(INFO.niftiPath, INFO.logfileName);

    % Run DICOM IMPORT, if requested
    if any(ismember(INFO.preprocJobs, 'dicomImport'))
        preproc_dicomImport(INFO);
    end
    
    % Find out the names and number of EPI subfolders
    epiFolderInfo = dir(fullfile(INFO.niftiPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
    INFO.epiFolderNames = {epiFolderInfo.name}';
    INFO.numEpiRuns = length(INFO.epiFolderNames);
    
    % Run selected preprocessing jobs
    for job=1:length(INFO.preprocJobs)
        if ~strcmp(INFO.preprocJobs{job}, 'dicomImport') %don't repeat DICOM import
            eval(['preproc_' INFO.preprocJobs{job} '(INFO)']);
        end
    end
end