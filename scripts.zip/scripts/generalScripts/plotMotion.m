function plotMotion(INFO)

%-------------------------------------------------------------------------
% Plots motion for selected subjects and runs.
%
% Function called from run_scripts.m.
%-------------------------------------------------------------------------

% Loop through all subjects
for subject=INFO.subjects
    
    % Determine the names and number of EPI subfolders
    niftiPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, ...
        [INFO.dir.root.MRI.subj.name num2str(subject)], INFO.dir.root.MRI.subj.nifti.name);
    epiFolderInfo = dir(fullfile(niftiPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
    epiFolderNames = {epiFolderInfo.name}';
    numEpiRuns = length(epiFolderNames);
    
    % Go through each EPI folder
    for run = 1:numEpiRuns
        
        %% Plot motion
        % Load the motion parameters
        motionFile = dir(fullfile(niftiPath, epiFolderNames{run}, 'rp_*.txt'));
        if isempty(motionFile)
            disp(['ERROR: Motion regressors not found: ' fullfile(niftiPath, epiFolderNames{run}, 'rp_*.txt') ]);
            return
        end
        motionParams = load(fullfile(niftiPath, epiFolderNames{run}, motionFile.name));
        motionParams(:,4:6) = (motionParams(:,4:6).*180)./pi; %change from radians to degrees for ease of interpretability
        
        % Plot the motion parameters
        figure;
        subplot(2,1,1);plot(motionParams(:,1:3));
        xlim([0 size(motionParams,1)+1]);
        title(['Subject: ' num2str(subject) ', Run: ' epiFolderNames{run}], 'FontSize', 25);
        ylabel('Distance in mm', 'FontSize', 20);
        subplot(2,1,2);plot(motionParams(:,4:6));
        xlim([0 size(motionParams,1)+1]);
        xlabel('Scans', 'FontSize', 20);
        ylabel('Rotation in degrees', 'FontSize', 20);
    end
end