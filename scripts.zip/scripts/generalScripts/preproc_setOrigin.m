function preproc_setOrigin(INFO)

%-------------------------------------------------------------------------
% This script does not execute any codes but only provides instructions on
% how to set the image origin.
%-------------------------------------------------------------------------
disp(' ');
disp('<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>');
disp(['Preprocessing steps prior to setOrigin are completed for subject: ' INFO.subjStr]);
disp('Manually center anatomical and functional images to origin before proceeding!');
disp('To set the origin, select "Display" in the SPM GUI, and then choose the T1 image for');
disp('this subject. Press "Origin" at the top of the left menu to go to the current');
disp('image origin. Using the fields above, move the image so that the origin is at the');
disp('Anterior Commissure (AC). For pictures of how to identify the AC is in MRI images,');
disp('visit the link below. Once you''ve set the origin, press "Reorient..." at the bottom');
disp('and select the same anatomical image, followed by "Done".');
disp('Repeat this for the functional images by selecting a random volume. After pressing');
disp('on "Reorient..." select all EPI images for that subject by typing "1:1000" in the ');
disp('Filter box in order to show all EPI volumes. Remember to select all EPIs from other runs too');
disp('For help, visit wagerlab.colorado.edu/wiki/doku.php/help/fmri_help/preprocessing/anterior_commissure');
disp(' ');
disp('When you have set the origin for all images, update INFO.originSetFor in study_info.m');
disp('<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>');
disp(' ');