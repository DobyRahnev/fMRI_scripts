function preproc_extractPhysio(INFO)

%-------------------------------------------------------------------------
% Extracts physiological (heart rate and respiration) regressors for a
% single subject. Function called from preprocManager.m.
%-------------------------------------------------------------------------

% Get path to physio folder
physioPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, INFO.subjStr, INFO.dir.root.MRI.subj.dicom.name, INFO.dir.root.MRI.subj.dicom.physio.name);

% Check whether extract physio was performed already
physio_file_output = dir(fullfile(physioPath, INFO.epiFolderNames{INFO.numEpiRuns}, 'physio_regressors.txt'));
if ~isempty(physio_file_output)
    disp(['Physio extract requested but it was already performed for subject: ' INFO.subjStr '. Physio extract skipped.']);
    return
end

% Extract physio info for each run
for run = 1:INFO.numEpiRuns
    
    % Extract the PULS and RESP sequences from the DICOM file
    dcm_file = dir(fullfile(physioPath, INFO.epiFolderNames{run}, '*.dcm'));
    extractCMRRPhysio(fullfile(physioPath, INFO.epiFolderNames{run}, dcm_file.name));
    
    % Get file names for the PULS, RESP, and Info files
    file_PULS = dir(fullfile(physioPath, INFO.epiFolderNames{run}, '*_PULS.log'));
    if isempty(file_PULS)
        PULS_path = '';
    else
        PULS_path = fullfile(physioPath, INFO.epiFolderNames{run}, file_PULS.name);
    end
    file_RESP = dir(fullfile(physioPath, INFO.epiFolderNames{run}, '*_RESP.log'));
    if isempty(file_RESP)
        RESP_path = '';
    else
        RESP_path = fullfile(physioPath, INFO.epiFolderNames{run}, file_RESP.name);
    end
    file_INFO = dir(fullfile(physioPath, INFO.epiFolderNames{run}, '*_Info.log'));
    if isempty(file_INFO)
        INFO_path = '';
    else
        INFO_path = fullfile(physioPath, INFO.epiFolderNames{run}, file_INFO.name);
    end
    
    % Get info about #volumes, #slices, and TR from the header of first DICOM file
    epiFolderPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, INFO.subjStr, INFO.dir.root.MRI.subj.dicom.name, INFO.epiFolderNames{run});
    all_files = dir(fullfile(epiFolderPath, '*.dcm'));
    nVolumes = length(all_files);
    hdr = spm_dicom_headers(fullfile(epiFolderPath,all_files(1).name)); %header of first DICOM file
    num_slices = hdr{1}.Private_0019_100a;
    TR = hdr{1}.RepetitionTime/1000;
    
    % Check if TR is consistent with what was specified in study_info.m
    if TR ~= INFO.TR
        error(['TR specified in study_info.m (' num2str(INFO.TR) ') differs from TR read in DICOM header (' num2str(TR) ').']);
    end
    
    % Initialize the SPM batch
    clear matlabbatch
    spm('defaults', 'fmri');
    spm_jobman('initcfg');
    
    % Perform creation of  correction
    fprintf(['======\n' 'Performing EXTRACT PHYSIO for subject: ' INFO.subjStr ', run: ' num2str(run) '\n======\n']);
    matlabbatch{1}.spm.tools.physio.save_dir = {fullfile(physioPath, INFO.epiFolderNames{run})};
    matlabbatch{1}.spm.tools.physio.log_files.vendor = 'Siemens_Tics';
    matlabbatch{1}.spm.tools.physio.log_files.cardiac = {PULS_path};
    matlabbatch{1}.spm.tools.physio.log_files.respiration = {RESP_path};
    matlabbatch{1}.spm.tools.physio.log_files.scan_timing = {INFO_path};
    matlabbatch{1}.spm.tools.physio.log_files.align_scan = 'first'; %align to first because in some studies last few volumes are deleted
    matlabbatch{1}.spm.tools.physio.scan_timing.sqpar.Nslices = num_slices;
    matlabbatch{1}.spm.tools.physio.scan_timing.sqpar.TR = INFO.TR;
    matlabbatch{1}.spm.tools.physio.scan_timing.sqpar.Ndummies = INFO.numVolToRemove;
    matlabbatch{1}.spm.tools.physio.scan_timing.sqpar.Nscans = nVolumes;
    matlabbatch{1}.spm.tools.physio.scan_timing.sqpar.onset_slice = 1;
    matlabbatch{1}.spm.tools.physio.preproc.cardiac.modality = 'PPU';
    matlabbatch{1}.spm.tools.physio.model.output_multiple_regressors = 'physio_regressors.txt';
    matlabbatch{1}.spm.tools.physio.model.output_physio = 'physio.mat';
    spm_jobman('run',matlabbatch);
end

% Save preprocessing step details
load(INFO.logfile);
preprocDone.extractPhysio.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');