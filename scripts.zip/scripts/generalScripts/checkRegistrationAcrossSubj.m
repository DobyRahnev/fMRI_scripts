function checkRegistrationAcrossSubj(INFO, subjList)

%-------------------------------------------------------------------------
% Lets the user manually check the registration between the T1 images of
% several subjects.
%
% Function called from run_scripts.m.
%-------------------------------------------------------------------------

%Go through each subject
for subjNum=1:length(subjList)
    
    % Determine the name of normalized anatomical file
    niftiPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, ...
        subjList{subjNum}, INFO.dir.root.MRI.subj.nifti.name);
    anatFile = dir(fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, ['w' INFO.nameAppend.anat '*.nii']));
    if isempty(anatFile)
        disp(['ERROR: Anatomical image not found: ' fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, ['w' INFO.nameAppend.anat '*.nii']) ]);
        return
    end
    anatFileNames{subjNum} = fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, anatFile.name);
end
char(anatFileNames)
% Perform the registration check
spm_check_registration(char(anatFileNames));
