function preproc_smooth(INFO)

%-------------------------------------------------------------------------
% Smooths EPI data for a single subject. Function called from
% preprocManager.m.
%-------------------------------------------------------------------------

% Check whether smoothing was performed already
smoothFiles = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, [INFO.nameAfter.smooth '*.nii']));
if ~isempty(smoothFiles)
    disp(['Smoothing requested but it was already performed for subject: ' INFO.subjStr '. Smoothing skipped.']);
    return
end

% Determine the names of the files to smooth
filesToSmooth = [];
for run = 1:INFO.numEpiRuns
    % Determine the name of the 4D file to smooth
    filePreviousStep = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.smooth '*.nii']));
    if isempty(filePreviousStep)
        disp(['ERROR: File for smooth not found: ' fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.smooth '*.nii']) ]);
        disp('Check that the previous preprocessing step in INFO.preprocOrder was completed');
        return
    end
    fileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, filePreviousStep.name);
    
    % Determine the number of volumes in the 4D file
    volumeInfo = spm_vol(fileName);
    numVolumes = length(volumeInfo);
    
    % Concatenate all individual volumes from the 4D file
    for volume=1:numVolumes
        filesToSmooth{end+1,1} = [fileName ',' num2str(volume)];
    end
end

% Initialize the SPM batch
clear matlabbatch
spm('defaults', 'fmri');
spm_jobman('initcfg');

% Perform smoothing
fprintf(['======\n' 'Performing SMOOTH for subject: ' INFO.subjStr '\n======\n']);
matlabbatch{1}.spm.spatial.smooth.data = filesToSmooth;
matlabbatch{1}.spm.spatial.smooth.fwhm = INFO.FWHM;
matlabbatch{1}.spm.spatial.smooth.prefix = INFO.nameAppend.smooth;
spm_jobman('run',matlabbatch);

% Save preprocessing step details
load(INFO.logfile);
preprocDone.smooth.matlabbatch = matlabbatch;
save(INFO.logfile, 'preprocDone');