function preproc_despike(INFO)

%-------------------------------------------------------------------------
% Performs despiking for a single subject. Function called from 
% preprocManager.m.
%-------------------------------------------------------------------------

% Check whether despiking was performed already
despikedFiles = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{1}, [INFO.nameAfter.despike '*.nii']));
if ~isempty(despikedFiles)
    disp(['Despiking requested but it was already performed for subject: ' INFO.subjStr '. Despiking skipped.']);
    return
end

% Go through all runs
for run=1:INFO.numEpiRuns
    
    % Find file and determine file name for despiked file
    filePreviousStep = dir(fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.despike '*.nii']));
    if isempty(filePreviousStep)
        disp(['ERROR: File for despiking not found: ' fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameBefore.despike '*.nii']) ]);
        disp('Check that the previous preprocessing step in INFO.preprocOrder was completed');
        return
    end
    nonDespikedFileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, filePreviousStep.name);
    despikedFileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, [INFO.nameAppend.despike filePreviousStep.name]);
    spikesFileName = fullfile(INFO.niftiPath, INFO.epiFolderNames{run}, ['spikes_' filePreviousStep.name]);
    
    % Perform despike (produces spikes_*.nii with spike info)
    fprintf(['======\n' 'Performing DESPIKE using AFNI for subject: ' INFO.subjStr '\n======\n']);
    system(['3dDespike -cut ' num2str(INFO.spikeDetectThresh) ' ' num2str(INFO.spikeUpperBound) ...
        ' -prefix ''' despikedFileName ''' -ssave ''' spikesFileName ''' -localedit ' nonDespikedFileName]);
end

% Save preprocessing step details
load(INFO.logfile);
preprocDone.despike.spikeDetectThresh = INFO.spikeDetectThresh;
preprocDone.despike.spikeUpperBound = INFO.spikeUpperBound;
save(INFO.logfile, 'preprocDone');