function secondLevel(INFO)

%-------------------------------------------------------------------------
% Computes standard second level model based on first level results.
%
% This file is to be called from run_scripts.m which controls what
% processing steps to run.
%-------------------------------------------------------------------------

% Determine names and paths
secondLevelPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, INFO.dir.root.MRI.second_level.name);
secondLevelModelPath = fullfile(secondLevelPath, INFO.model);

% Check if folder for second level models is created
if ~exist(secondLevelPath, 'dir')
    mkdir(secondLevelPath);
end
if exist(secondLevelModelPath, 'dir')
    rmdir(secondLevelModelPath, 's');
end
mkdir(secondLevelModelPath);

% Determine the number of contrasts
subj1_str = [INFO.dir.root.MRI.subj.name num2str(INFO.subjects(1))]; %subject in string
subj1_path = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subj1_str);
subj1_firstLevelModelPath = fullfile(subj1_path, INFO.dir.root.MRI.subj.first_level.name, INFO.model);
numberContrasts = length(dir([subj1_firstLevelModelPath '/con*.nii']));

% Loop though all the contrasts
for contrastIdx = 1:numberContrasts
    
    % Contrast scans will be put in this variable
    allContrastFiles = '';
    
    % Loop through the subjects
    for subject = INFO.subjects
        
        % Determine names and paths
        subjStr = [INFO.dir.root.MRI.subj.name num2str(subject)]; %subject in string
        subjPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, subjStr);
        firstLevelModelPath = fullfile(subjPath, INFO.dir.root.MRI.subj.first_level.name, INFO.model);
        
        % In the file name, the contrast number is padded with zeroes
        contrastIdxChar = num2str(contrastIdx);
        while(length(contrastIdxChar) ~= 4)
            contrastIdxChar = [num2str(0) contrastIdxChar];
        end
        subjectContrastFile = [firstLevelModelPath '/con_' contrastIdxChar '.nii'];
        allContrastFiles = strvcat(allContrastFiles,subjectContrastFile);
    end
    
    % Make the output folder for second level SPM.mat
    load(fullfile(firstLevelModelPath, 'SPM.mat'));
    contrast_name = SPM.xCon(contrastIdx).name;
    clear SPM;
    contrastsSpecificSecondLevelPath = [secondLevelModelPath '/Contrast' num2str(contrastIdx) '_' contrast_name];
    mkdir(contrastsSpecificSecondLevelPath);
    
    % Initialize the SPM batch
    clear matlabbatch
    spm('defaults', 'fmri');
    spm_jobman('initcfg');
    
    % Set up the second level
    matlabbatch{1}.spm.stats.factorial_design.dir = cellstr(contrastsSpecificSecondLevelPath);
    matlabbatch{1}.spm.stats.factorial_design.des.t1.scans = cellstr(allContrastFiles);
    %     matlabbatch{1}.spm.stats.factorial_design.cov(1).c = covariateVariable;
    %     matlabbatch{1}.spm.stats.factorial_design.cov(1).cname = 'covariate name';
    fprintf(['======\n' 'SPECIFYING SECOND LEVEL for model: ' INFO.model ', contrast: ' num2str(contrastIdx) ' out of ' num2str(numberContrasts) '\n======\n']);
    spm_jobman('run', matlabbatch);
    
    % Re-initialize the SPM batch
    clear matlabbatch;
    spm('defaults', 'fmri');
    spm_jobman('initcfg');
    
    %Estimate the second level
    matlabbatch{1}.spm.stats.fmri_est.spmmat = {[contrastsSpecificSecondLevelPath '/SPM.mat']};
    matlabbatch{1}.spm.stats.fmri_est.method.Classical = 1;
    fprintf(['======\n' 'ESTIMATING SECOND LEVEL for model: ' INFO.model ', contrast: ' num2str(contrastIdx) ' out of ' num2str(numberContrasts) '\n======\n']);
    spm_jobman('run', matlabbatch);
end