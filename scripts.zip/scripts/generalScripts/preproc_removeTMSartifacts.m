%-------------------------------------------------------------------------
% preproc_removeTMSspikes.m
%
% Removes artifacts associated with delivery of precisely-timed TMS
% pulses. Note that if there is a large error in the estimate of the time
% of delivery of the TMS pulses, this procedure will not work well.
%
% To function properly, this function assumes that the following info is
% present in the results file:
%   -p.TMS_times: timing of the TMS pulses
%   -p.burst.numberPulses: number of pulses in a burst
%   -p.burst.frequency: frequency (Hz) of pulses in a burst
% For single pulses, p.burst should not exist.
%
% NB! Three more parameters should be set in the beginning of this script!
%
% Function called from preprocManager.m.
%-------------------------------------------------------------------------

%% Set these parameters
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
timingUncertainty = .01;   %error in TMS pulse times (usually 5 to 10 ms)
tmsDelay = .0684;          %delay in TMS pulses (at UC Berkeley, 28 ms)
spikeSD = 4;               %threshold in SD for detecting spikes (usually 4 or 5)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%% Check whether removal of TMS artifacts was performed already
tmsFiles = dir(fullfile(niftiPath, epiFolderNames{1}, [INFO.nameAfter.tms '*.nii']));
if ~isempty(tmsFiles)
    disp(['Removal of TMS artifacts requested but it was already performed for subject: ' subjStr '. TMS artifact removal skipped.']);
    return
end
fprintf(['======\n' 'Performing REMOVAL OF TMS ARTIFACTS for subject: ' subjStr '\n======\n']);

%% Loop through all runs
for run = 1:numEpiRuns
    
    % Determine the name of the 4D file to use
    filePreviousStep = dir(fullfile(niftiPath, epiFolderNames{run}, [INFO.nameBefore.tms '*.nii']));
    if isempty(filePreviousStep)
        disp(['ERROR: File for TMS artifact removal not found: ' fullfile(niftiPath, epiFolderNames{run}, [INFO.nameBefore.tms '*.nii']) ]);
        disp('Check that the previous preprocessing step in INFO.preprocOrder was completed');
        return
    end
    fileName = fullfile(niftiPath, epiFolderNames{run}, filePreviousStep.name);
    
    % Determine the number of volumes and slices in the 4D file
    headerInfo = spm_vol(fileName);
    epiData = spm_read_vols(headerInfo);
    numSlices = size(epiData,3);
    numVolumes = size(epiData,4);
    
    
    %% Compute which slices should be cleaned up
    % Load behavioral data file with TMS pulse times
    behavPath = fullfile(INFO.dir.root.name, INFO.dir.root.analyses.name, INFO.dir.root.analyses.behavData.name, subjStr);
    behavioralDataFile = fullfile(behavPath, ['results_' epiFolderNames{run} '.mat']);
    load(behavioralDataFile);
    
    % Compute start time for each burst (or single pulse)
    burstOnsets = p.TMS_times - INFO.numVolToRemove*INFO.TR + tmsDelay;
    pulseOnsets = burstOnsets;
    
    % If bursts were delivered, compute timing for each pulse separately
    if isfield(p,'burst')
        interPulseInterval = 1/p.burst.frequency;
        for pulseInBurst=2:p.burst.numberPulses
            pulseOnsets = [pulseOnsets, burstOnsets + interPulseInterval*(pulseInBurst-1)];
        end
    end
    
    % Estimate which slices were affected by TMS
    volumes = ceil(pulseOnsets/INFO.TR);
    timeFromVolumeOnset = pulseOnsets - floor(pulseOnsets/INFO.TR)*INFO.TR;
    sliceInVolume = ceil(timeFromVolumeOnset/INFO.TR * numSlices);
    
    % If TMS pulses came close to the slice beginning or end, remove the
    % adjacent slice too
    tmsTimeInSlice = timeFromVolumeOnset - floor(timeFromVolumeOnset/INFO.TR*numSlices)/numSlices*INFO.TR;
    for pulse=1:length(pulseOnsets)
        if tmsTimeInSlice(pulse) < timingUncertainty %too close to previous slice
            if sliceInVolume(pulse) == 1 %change last slice of previous volume
                volumes(end+1) = volumes(pulse)-1;
                sliceInVolume(end+1) = numSlices;
            else
                volumes(end+1) = volumes(pulse);
                sliceInVolume(end+1) = sliceInVolume(pulse) - 1;
            end
        elseif INFO.TR/numSlices - tmsTimeInSlice(pulse) < timingUncertainty %too close to next slice
            if sliceInVolume(pulse) == numSlices %change first slice of next volume
                volumes(end+1) = volumes(pulse)+1;
                sliceInVolume(end+1) = 1;
            else
                volumes(end+1) = volumes(pulse);
                sliceInVolume(end+1) = sliceInVolume(pulse) + 1;
            end
        end
    end
    
    % Put all affected slices together
    tmsSlices = zeros(numSlices, numVolumes);
    tmsSlices(sub2ind(size(tmsSlices), sliceInVolume, volumes)) = 1;
    
    % Correct for the acquisition direction
    if strcmp(INFO.sliceAquisition, 'descending')
        sliceInVolume = numSlices + 1 - sliceInVolume;
    elseif ~strcmp(INFO.sliceAquisition, 'ascending')
        disp('This acquisition sequence is not supported. If you don''t have ascending or descending sequence; edit preproce_removeTMSspike.m to add functionality for interleaved sequences');
        return;
    end
    
    
    %% Clean the TMS-affected slices
    % Make each slice with a (suspected) TMS-induced spike the average the
    % of the same slice from the volumes before and after it
    epiDataNew = epiData;
    for pulse = 1:length(sliceInVolume)
        if volumes(pulse) == 1
            epiDataNew(:,:,sliceInVolume(pulse),volumes(pulse)) = epiData(:,:,sliceInVolume(pulse),2);
        elseif volumes(pulse) == numVolumes
            epiDataNew(:,:,sliceInVolume(pulse),volumes(pulse)) = epiData(:,:,sliceInVolume(pulse),numVolumes-1);
        else
            epiDataNew(:,:,sliceInVolume(pulse),volumes(pulse)) = (epiData(:,:,sliceInVolume(pulse),volumes(pulse)-1) + ...
                epiData(:,:,sliceInVolume(pulse),volumes(pulse)+1)) / 2;
        end
    end
    
    
    %% Write new file
    headerNew = headerInfo;
    newFileName = fullfile(niftiPath, epiFolderNames{run}, [INFO.nameAppend.tms filePreviousStep.name]);
    for volume = 1:numVolumes
        headerNew(volume).fname = newFileName;
        headerNew(volume).private.dat.fname = newFileName;
        spm_write_vol(headerNew(volume), epiDataNew(:,:,:,volume));
    end
    
    
    %% Find the spikes actually present in the data
    % compute mean and SD across the entire slice
    epiMeanSlices = mean(mean(epiData,2),1);
    epiMeanSlices = reshape(epiMeanSlices,numSlices,numVolumes);
    stdevSlice = std(epiMeanSlices, 0, 2);
    
    % Find slices with spikes and compute their start times
    %detect the slices with spikes
    detectedSpikes = abs(epiMeanSlices - repmat(mean(epiMeanSlices,2),1,numVolumes)) > spikeSD*repmat(stdevSlice,1,numVolumes);
    %concatenate the slices from 1 to numVolumes*numSlices
    spikeAbsoluteSliceNum = find(detectedSpikes)';
    %for each spike, compute how many volumes were collected before it
    volumesBefore = floor((spikeAbsoluteSliceNum-1)/numSlices);
    %for each spike, compute how many slices were collected before it
    if strcmp(INFO.sliceAquisition, 'ascending')
        slicesBefore = spikeAbsoluteSliceNum - numSlices*volumesBefore - 1;
    elseif strcmp(INFO.sliceAquisition, 'descending')
        slicesBefore = numSlices + 1 - (spikeAbsoluteSliceNum - numSlices*volumesBefore);
    end
    % For each spike, this is the start of the INFO.TR/numSlices period
    % when the TMS pulse must have arrived
    actualSpikeTimes = volumesBefore*INFO.TR + (slicesBefore-1)*INFO.TR/numSlices;
    
    
    %% Ascecrtain that tmsDelay specified above is correct (i.e., the delay between TMS pulse and spikes)
    for i=1:length(actualSpikeTimes)
         %Find TMS pulse immediately before the end of the slice with spike
        pulseCausingSpike = timeAllPulses(find(pulseOnsets < actualSpikeTimes(i)+INFO.TR/numSlices, 1, 'last'));
        delay(i) = pulseCausingSpike - actualSpikeTimes(i);
    end
    sortedDelays = sort(delay)
    expectedInterval = [0 INFO.TR/numSlices]
    text = ['For conservative spike thresholds, the sortedDelays variable should fall completely \n'...
        'within the expectedInterval. If that is not the case, perhaps the tmsDelay delay variable \n'...
        'needs to be adjusted. Large negative outliers indicate spikes that were not caused by TMS.\n\n'];
    fprintf(text);


    %% Plot actual spikes and TMS predictions
    tmsAbsoluteSliceNum = find(tmsSlices)';
    unionEvents = union(tmsAbsoluteSliceNum,spikeAbsoluteSliceNum);
    intersectEvents = intersect(tmsAbsoluteSliceNum,spikeAbsoluteSliceNum);
    figure
    plot([.5 length(unionEvents)+.5], [0 0], 'k');
    hold
    h(1)=plot([i i], [-1 1], 'g');
    h(2)=plot([i i], [-1 1], 'r');
    h(3)=plot([i i], [-1 1], 'b');
    for i=1:length(unionEvents)
        if sum(intersectEvents==unionEvents(i))==1
            color = 'g';
        elseif sum(spikeAbsoluteSliceNum==unionEvents(i))==1
            color = 'r';
        else
            color = 'b';
        end
        plot([i i], [-1 1+mod(i,10)/3], color, 'LineWidth', 2);
        vol = ceil(unionEvents(i)/numSlices);
        slice = unionEvents(i)-floor(unionEvents(i)/numSlices)*numSlices;
        %text(i-.5, 2+mod(i,10)/3, num2str(unionEvents(i)));
        text(i-.5, 2+mod(i,10)/3, [num2str(vol) ',' num2str(slice)]);
    end
    ylim([-1 8]);
    xlabel('Many red lines indicate potential issues with the timing of the TMS pulses. The numbers above the lines indicate the volume and slice of each event.');
    legend(h, 'TMS pulse + Spike (GOOD)', 'Spike only (BAD)', 'TMS pulse only (conservative)');
    title(['TMS artifacts for Subject: ' subjStr ', Run: ' epiFolderNames{run}], 'FontSize', 25);
    set(gcf,'Units','pixels','Position',[0 0 9999 9999]); %make figure maximally large
    
end

% Save preprocessing step details
load(logfile);
preprocDone.tms.timingUncertainty = timingUncertainty;
preprocDone.tms.tmsDelay = tmsDelay;
preprocDone.tms.spikeSD = spikeSD;
save(logfile, 'preprocDone');