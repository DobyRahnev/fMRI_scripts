function checkRegistration(INFO, subjStr, preprocStep)

%-------------------------------------------------------------------------
% Lets the user manually check the registration between the T1 and the EPI
% images.
%
% Function called from run_scripts.m.
%-------------------------------------------------------------------------


% Determine the names and number of EPI subfolders
niftiPath = fullfile(INFO.dir.root.name, INFO.dir.root.MRI.name, ...
    subjStr, INFO.dir.root.MRI.subj.nifti.name);
epiFolderInfo = dir(fullfile(niftiPath, [INFO.dir.root.MRI.subj.dicom.epi.name '*']));
epiFolderNames = {epiFolderInfo.name}';

% Determine the names of first EPI file and anatomical file
if ~isfield(INFO.nameAfter, preprocStep)
    Error('Unrecognized preprocessing step. Set the second parameter in plotTimecourses.m to func, despike, sliceTime, realign, norm, or smooth');
else
    % Determine the file to plot data from
    nameAppend = eval(['INFO.nameAfter.' preprocStep]);
    file = dir(fullfile(niftiPath, epiFolderNames{1}, [nameAppend '*.nii']));
    if isempty(file)
        error(['Files for registration check not found. Requested file name: ' fullfile(niftiPath, epiFolderNames{1}, nameAppend) '*.nii']);
    end
    epiFileName = fullfile(niftiPath, epiFolderNames{1}, [file.name ',1']);
    
    % Determine the name of the anatomical image
    anatFile = dir(fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, [INFO.nameAppend.anat '*.nii']));
    if isempty(anatFile)
        disp(['ERROR: Anatomical image not found: ' fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, [INFO.nameAppend.anat '*.nii']) ]);
        return
    end
    anatFileName = fullfile(niftiPath, INFO.dir.root.MRI.subj.dicom.anat.name, anatFile.name);
end

% Perform the registration check
spm_check_registration(anatFileName, epiFileName);
